# Sieć neuronowa klasyfikująca białaczki

## Uruchamianie

```python
pip install -r requirements.txt
jupyter notebook
```
